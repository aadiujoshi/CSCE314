public class Hello {
    public static void greet() {
        System.err.println("HIIIIIII");
    }
}
